#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "sft_client.h"


int main(int argc, char const *argv[])
{
    
    /*open requests.txt
    *send each file requst to the function 
    *make_request(char* request, char* server, int port)
    *the request is the filename, the server is 127.0.0.1 and the port is 1600
    */
    return 0;
}
