 #include <stdio.h>
 #include <string.h>
 #include <stdlib.h>
 #include <sys/socket.h>
 #include <unistd.h>
 #include <netdb.h>
 #define BUFFER_SIZE 1600


void start_server(int port)
{
    
/*Start the server on given port
*receive request, parse reqeust to get filename
*open that file and return contents to client
*/
    
}